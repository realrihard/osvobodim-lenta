<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/scss/app.scss', 'resources/js/app.js']); ?>
    <title>Document</title>
</head>

<body>
    <div class="container mx-auto">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html>
<?php /**PATH E:\Rihard\Work 2023\Osvobodim\projects\osvobodim-galery\resources\views/app.blade.php ENDPATH**/ ?>