<?php $__env->startSection('content'); ?>
    <div id="app">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rihard\Work 2023\Osvobodim\projects\osvobodim-galery\resources\views/index.blade.php ENDPATH**/ ?>