<?php $__env->startSection('content'); ?>
    <div class="header">
        <div>
            <h1>Application Title</h1>
        </div>
        <div>
            <a href="<?php echo e(url('admin/create')); ?>">Create new post</a>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>Discription</th>
                <th>Suma</th>
                <th>Image</th>
                <th width="280px">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->description); ?></td>
                    <td><?php echo e($post->suma); ?></td>
                    <td><img src="/images/<?php echo e($post->image); ?>" width="100px"></td>
                    <td>
                        <form action="" method="POST">
                            <a href="#">Show</a>
                            <a href="#">Edit</a>

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rihard\Work 2023\Osvobodim\projects\osvobodim-galery\resources\views/admin.blade.php ENDPATH**/ ?>