<?php $__env->startSection('content'); ?>
    <div id="app">
        <Smoothie class="content">
            <div class="container">
                <div class="header">
                    <ul class="header__menu">
                        <li>
                            <a href="/">Перейти на сайт</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <li class="nav-item dropdown">
                            <?php echo e(Auth::user()->name); ?>


                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Выйти')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <dashboard />
        </Smoothie>

        <post-panel />
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rihard\Work 2023\Osvobodim\projects\osvobodim-galery\resources\views/dashboard.blade.php ENDPATH**/ ?>