<?php $__env->startSection('content'); ?>
    <div class="header">
        <h1>Create post</h1>
        <a href="/admin">Вернуться</a>
    </div>

    <?php if($errors->any()): ?>
        <div>
            <strong>Woops!</strong> Something wrong <br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <input type="text" name="description" placeholder="Описание">
        <input type="text" name="suma" placeholder="Сумма">
        <input type="file" name="image">
        <button type="submit">Отправить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rihard\Work 2023\Osvobodim\projects\osvobodim-galery\resources\views/create.blade.php ENDPATH**/ ?>