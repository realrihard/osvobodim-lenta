<?php $__env->startSection('content'); ?>
    <div class="header">
        <div>
            <h1>Вариант 1</h1>
        </div>
    </div>

    <div id="app">
        <test />
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rihard\Work 2023\Osvobodim\projects\osvobodim-galery\resources\views/grid1.blade.php ENDPATH**/ ?>